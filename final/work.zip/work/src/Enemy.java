package mrfoops;

import java.awt.Image;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.Random;

public class Enemy{


	private Board board;

	protected ArrayList<Ball> balllist;
	private Random ran = new Random();

	private double w;
	private double h;
	private double dw;
	private double dh;
	private double orix; // x for w
	private double oriy; // y for h

	private double f; // v = frequecy of throw ball
	private double count;


	public Enemy(double w, double h, double dw, double dh, double orix, double oriy, Board b, double f){
		this.balllist = new ArrayList<Ball>();
		this.w = w;
		this.h = h;
		this.dw = dw;
		this.dh = dh;
		this.orix = orix;
		this.oriy = oriy;
		this.board = b;
		this.f = f;
		this.count = 0;
	}

	public ArrayList<Ball> throwBalls(){
		
		ArrayList<Ball> newBalls = new ArrayList<Ball>();
		this.count += 1;
		if(count%f!=0)
			return newBalls;

		int dir = ran.nextInt(4); //0, 1, 2, 3

		int startx;
		int starty;
		if(dir==0 || dir==1){
			//dir: -1, 0 or 1, 0
			startx = 9 - 9*dir;
			starty = ran.nextInt(8)+1;
			newBalls.add(new Ball(this.dw, this.dh, 8, 8, startx*this.orix, starty*this.oriy, dir, 1.0/50, this, this.board));
			starty = ran.nextInt(8)+1;
			newBalls.add(new Ball(this.dw, this.dh, 8, 8, startx*this.orix, starty*this.oriy, dir, 1.0/50, this, this.board));
			starty = ran.nextInt(8)+1;
			newBalls.add(new Ball(this.dw, this.dh, 8, 8, startx*this.orix, starty*this.oriy, dir, 1.0/50, this, this.board));
		}else{
			starty = 9 - 9*(dir%2);
			startx = ran.nextInt(8)+1;
			newBalls.add(new Ball(this.dw, this.dh, 8, 8, startx*this.orix, starty*this.oriy, dir, 1.0/50, this, this.board));
			startx = ran.nextInt(8)+1;
			newBalls.add(new Ball(this.dw, this.dh, 8, 8, startx*this.orix, starty*this.oriy, dir, 1.0/50, this, this.board));
			startx = ran.nextInt(8)+1;
			newBalls.add(new Ball(this.dw, this.dh, 8, 8, startx*this.orix, starty*this.oriy, dir, 1.0/50, this, this.board));
		}
		this.balllist.addAll(newBalls);
		return newBalls;
	}
}