package mrfoops;

import java.awt.Color;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JPanel;
import javax.swing.Timer;

import java.awt.BasicStroke;
import java.awt.Dimension;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.Random;


public class Board extends JPanel implements ActionListener {

	private Timer timer;
	private Man man;
	protected ArrayList<Ball> obstacleList;
	private Enemy enemy;
	private final int DELAY = 1;
	private long count; //for man
	private long obsCount;
	private double w;
	private double h;
	private double dw;
	private double dh;
	private double orix; // x for w
	private double oriy; // y for h
	private boolean hit;

	public Board() {

		initBoard();
	}

	private void initBoard() {

		addKeyListener(new TAdapter());
		setFocusable(true);
		setBackground(Color.CYAN);

		this.count = 0;
		this.obsCount = 0;

		this.w = 400;
		this.h = 320;
		// 8*8
		this.dw = (w/8);
		this.dh = (h/8);

		this.orix = 50;
		this.oriy = 40;

		this.hit = false;
		System.out.printf("dw: %f\n",this.dw);
		System.out.printf("dh: %f\n",this.dh);

		man = new Man(this.dw, this.dh, 8, 8, this.orix, this.oriy);

		obstacleList = new ArrayList<Ball>();

		enemy = new Enemy(this.w, this.h, this.dw, this.dh, this.orix, this.oriy, this, 500);


		timer = new Timer(DELAY, this);
		timer.start();        
	}


	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);

		drawBoard(g);
		doDrawing(g);

		Toolkit.getDefaultToolkit().sync();
	}

	private void drawBoard(Graphics g) {

		Graphics2D g2d = (Graphics2D) g;

		RenderingHints rh
			= new RenderingHints(RenderingHints.KEY_ANTIALIASING,
					RenderingHints.VALUE_ANTIALIAS_ON);

		rh.put(RenderingHints.KEY_RENDERING,
				RenderingHints.VALUE_RENDER_QUALITY);

		g2d.setRenderingHints(rh);
		g2d.setColor(Color.WHITE);
		
		//draw Board
		Rectangle2D[] r = new Rectangle2D[64];
		for(int i=0; i<64; i++) {
			r[i] = new Rectangle2D.Double(orix + (i%8)*dw, oriy + (i/8)*dh, dw, dh);
			g2d.setStroke(new BasicStroke(2));

			g2d.setColor(Color.WHITE);
			// fill = fill in white
			g2d.fill(r[i]);

			g2d.setColor(Color.BLACK);
			// draw = only rectangles
			g2d.draw(r[i]);
		}
		if(hit){
			g2d.setColor(Color.red);
		    g2d.drawString("HIT!!", 30, 30);

		}
		
		
	}

	private void doDrawing(Graphics g) {

		Graphics2D g2d = (Graphics2D) g;
		// g2d.drawImage(man.getImage(), man.getX(), man.getY(), this); 
		// draw = concrete x, y
		man.draw(this, g2d);
		for(int i = 0; i < obstacleList.size(); i++){
			// testdraw = draw by pixel, not concrete
			obstacleList.get(i).testdraw(this, g2d);
		}       
	}

	private boolean checkHit(){
		int posx = man.getX();
		int posy = man.getY();

		for(int i = 0; i < obstacleList.size(); i++){
			int obsx = obstacleList.get(i).getX();
			int obsy = obstacleList.get(i).getY();
			if(posx == obsx && posy == obsy){
				System.out.printf("HIT!!!!!");
				return true;
			}
		}
		return false;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		this.count += 1;
		this.obsCount += 1;
		if(this.count>10){
			if(man.checkMove) {
				man.move();
				// tmp: if move again, as a new game
				this.hit = false;
				repaint();
			}
				
			this.count = 0;
		}

		// refresh and move obstacles by timer frequency
		for(int i = 0; i < obstacleList.size(); i++){
				obstacleList.get(i).testmove();
		}
		// System.out.println(obstacleList.size());
		if(checkHit()){
			this.hit = true;
		}
		obstacleList.addAll(enemy.throwBalls());
		// // throw ball frequecy
		// if(this.obsCount%500 == 0){
		// 	//obstacleList.clear();
		// 	obstacleList.addAll(enemy.throwBalls());
		// }
		
		repaint();
	}

	private class TAdapter extends KeyAdapter {

		@Override
			public void keyReleased(KeyEvent e) {
				man.keyReleased(e);
			}

		@Override
			public void keyPressed(KeyEvent e) {
				man.keyPressed(e);
			}
	}
}
