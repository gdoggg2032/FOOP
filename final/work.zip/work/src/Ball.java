package mrfoops;

import java.awt.Image;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import java.awt.Graphics2D;

public class Ball {



	private Board board;
	private Enemy enemy;

	private int dw;
	private int dh;

	private int row;
	private int col;
	private int dx;
	private int dy;
	private int x;
	private int y;
	private Image image;
	private int orix;
	private int oriy;
	private int dir;

	private double px;
	private double py;
	private double v;




	public Ball(double dw, double dh, int row, int col, double orix, double oriy, int dir, double v, Enemy e, Board b) { // for obstacle's test

		this.dw = (int)dw;
		this.dh = (int)dh;
		this.row = row;
		this.col = col;
		this.orix = (int)orix;
		this.oriy = (int)oriy;
		initBall();
		this.dir = dir;
		this.v = v;

		this.enemy = e;
		this.board = b;

	}

	private void initBall() {

		ImageIcon ii = new ImageIcon("./image/craft.png");
		image = ii.getImage();
		x = 0;
		y = 0;
		px = 0;
		py = 0;        
	}

	private void suicide(){

		this.enemy.balllist.remove(this);
		this.board.obstacleList.remove(this);
	}


	public void testmove(){
		// x += (1-this.dir/2)*((this.dir%2)*2-1);
		// y += (this.dir/2)*((this.dir%2)*2-1);
		px += (double)((1-this.dir/2)*((this.dir%2)*2-1)) * this.v;
		py += (double)((this.dir/2)*((this.dir%2)*2-1)) * this.v;
		x = (int)(px);
		y = (int)(py);


		if(this.getPX()<0 || this.getPY() <0 || this.getPY() > (this.row+2)*dh || this.getPX() > (this.col+2)*dw){

			System.out.printf(">>>>>>%d/%d, %d/%d\n", x, this.col, y, this.row);
			System.out.printf("before suicide: obstacleList.size(): %d\n", this.board.obstacleList.size());
			this.suicide();
			System.out.printf("after suicide: obstacleList.size(): %d\n", this.board.obstacleList.size());
		}
		
	}

	public int getX() {
		return 25 + (x * dw) + this.orix;
	}

	public int getY() {
		return 15 + y * dh + this.oriy;
	}

	public int getPX() {
		return 25 + (int)(px * dw) + this.orix;
	}

	public int getPY() {
		return 15 + (int)(py * dh) + this.oriy;
	}

	public Image getImage() {
		return image;
	}


	public void testdraw(Board b, Graphics2D g2d){
		g2d.drawImage(this.getImage(), this.getPX(), this.getPY(), b); 
	}

}
